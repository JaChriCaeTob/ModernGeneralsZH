Generals and Zero Hour: 64-bit program + Vulkan renderer (experimental), version 0.3.0

You need your own copy of the game(s) (Command & Conquer: Generals 1.08 and/or Zero Hour 1.04) and a graphics card with a
Vulkan 1.3 driver. This archive contains no game files. It has one folder per game:

    Zero Hour\   for Command & Conquer: Generals - Zero Hour
    Generals\    for Command & Conquer: Generals (the base game)

Install (do this for each game you want)
1. Unzip this archive anywhere.
2. Copy the CONTENT of the matching folder (x64\, tools\ and the .bat files, not the folder itself) into the game folder:
   the one with the .big files (INIZH.big for Zero Hour, INI.big for Generals).
   With the EA app the two games usually sit next to each other, for example
       ...\Command and Conquer Generals Zero Hour\Command and Conquer Generals Zero Hour      (Zero Hour)
       ...\Command and Conquer Generals Zero Hour\Command and Conquer Generals                (Generals)
   Do not mix them: the Zero Hour files go to the Zero Hour folder, the Generals files to the Generals folder.
3. Start Play-Updated.bat (updated graphics) or Play-Original.bat (original rendering, for comparison).
   Do not start the .exe in x64\ directly and do not copy it over an original game file.
4. Both start windowed. Remove -win inside the .bat for fullscreen. Set the resolution in the in-game options or in Options.ini
   (the game keeps one Options.ini per game in Documents\Command and Conquer ... Data).
5. Optional: run Install-OptionsMenu.bat (needs Python 3) to get the graphics check boxes in Options > advanced display options.
   Without it every effect can still be switched in Options.ini (see the README on GitHub).
6. Optional: run Skip-IntroMovies.bat for a quick start without the EA logo and trailer. Nothing is deleted, the movies are moved
   to IntroMovies_off; Restore-IntroMovies.bat puts them back.

Uninstall: delete the x64 and tools folders and the .bat files you copied and, if you installed it, the Window folder
(run Restore-IntroMovies.bat first if you used it).

Experimental one-time project: no support, no updates. The Zero Hour version has had far more play time; the Generals version was
added later and is tested less. Source code and all settings:
https://github.com/JaChriCaeTob/ModernGeneralsZH
Written by Claude Code. Licenses: LICENSE.md and THIRD_PARTY_NOTICES.md (DXVK: zlib license, FFmpeg: LGPL).
