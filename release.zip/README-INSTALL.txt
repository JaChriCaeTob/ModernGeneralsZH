Zero Hour x64 + Vulkan renderer (experimental)

You need your own copy of Command & Conquer: Generals - Zero Hour 1.04 and a graphics card with a Vulkan 1.3 driver.
This archive contains no game files.

Install
1. Unzip everything into your Zero Hour folder (the one with generalszh.exe and the .big files).
   You get: x64\, Play-Updated.bat, Play-Original.bat, Install-OptionsMenu.bat, tools\.
2. Start Play-Updated.bat (updated graphics) or Play-Original.bat (original rendering, for comparison).
   Do not start x64\generalszh64.exe directly and do not copy it over generalszh.exe.
3. Both start windowed. Remove -win inside the .bat for fullscreen. Set the resolution in the in-game options or in Options.ini.
4. Optional: run Install-OptionsMenu.bat (needs Python 3) to get the graphics check boxes in Options > advanced display options.
   Without it every effect can still be switched in Options.ini (see the README on GitHub).

Uninstall: delete the x64 and tools folders, the .bat files and, if you installed it, the Window folder.

Experimental one-time project: no support, no updates. Source code and all settings:
https://github.com/JaChriCaeTob/ModernGeneralsZH
Written by Claude Code. Licenses: LICENSE.md and THIRD_PARTY_NOTICES.md (DXVK: zlib license, FFmpeg: LGPL).
