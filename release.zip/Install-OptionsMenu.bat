@echo off
rem Optional: adds the graphics check boxes to the in-game options menu. Needs Python 3. Reads the menu from your own game files and writes a patched copy next to them.
cd /d "%~dp0"
python tools\patch_options_wnd.py "%~dp0."
if errorlevel 1 echo Failed: is Python 3 installed and is this the Zero Hour folder?
pause

