@echo off
rem 64-bit Zero Hour. -useCwd keeps this folder as the working directory (loose Data\Cursors and Data\Movies are read from here).
cd /d "%~dp0"
rem Updated graphics: native Vulkan renderer with all enhancements (Options.ini can switch single effects off).
"%~dp0x64\generalszh64.exe" -useCwd -win %*

