@echo off
rem 64-bit Zero Hour. -useCwd keeps this folder as the working directory (loose Data\Cursors and Data\Movies are read from here).
cd /d "%~dp0"
rem Original rendering: Direct3D 8 through DXVK, no added effects.
set GENERALS_GFX=d3d8
set GENERALS_ORIGINAL=1
"%~dp0x64\generalszh64.exe" -useCwd -win %*

